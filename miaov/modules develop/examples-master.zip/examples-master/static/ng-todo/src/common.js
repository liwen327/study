define({
	// Which filter are we using?
	TodoFilter: '', // empty, active, completed

	// What is the enter key constant?
	ENTER_KEY: 13
});

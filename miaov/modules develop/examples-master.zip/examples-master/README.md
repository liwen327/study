# Examples for Sea.js

<http://seajs.github.io/examples>


How to Build
------------

First, you should install `spm` and `spm-build`:

```
$ npm install spm@2.x -g
$ npm install spm-build -g
```

Then, build it:

```
$ cd static/hello
$ make build
$ make deploy
```

Visit <http://docs.spmjs.org/> for detail information.


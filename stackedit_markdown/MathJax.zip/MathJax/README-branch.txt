This is release branch v2.4 of MathJax.

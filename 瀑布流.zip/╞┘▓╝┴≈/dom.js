/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2015-05-10 11:11:44
 * @version $Id$
 */
var dom={};
//获取元素的索引
dom.getIndex=function(ele){ 
	var index=0;
	var ele=ele.previousSibling;
	while(ele){　
		if(ele.nodeType===1){ 
			index++;
		}
		ele=ele.previousSibling
	}
	return index;
}
//将节点列表转化为数组
dom.toArray=function(list){
	try{ 
		return [].slice.call(list,0)
	}catch(e){　
		var arr=[];
		for(var i=0;i<list.length;i++){
			arr.push(list[i]); 
		}
		return arr;
	}
}
//获取元素距离顶部和左侧的距离
dom.getPos=function(ele){ 
	var pos={left:0,top:0};
	do{ 
		pos.left+=ele.offsetLeft;
		pos.top+=ele.offsetTop;
		ele=ele.offsetParent;
	}while(ele);
	return pos;
}
//获取元素的哥哥节点
dom.prev=function(ele){
	if(ele.previousElementSibling){
		return ele.previousElementSibling;
	}else{ 
		var pre=ele.previousSibling;
		while(pre){
			if(pre.nodeType===1){
				return pre;
			}
			pre=pre.previousSibling;
		}
	}
	 
	return null;
}
//获取元素的弟弟节点
dom.next=function(ele){
	if(ele.nextElementSibling){
		return ele.nextElementSibling;
	}else{ 
		var next=ele.nextSibling;
		while(next){
			if(next.nodeType===1){ 
				return next;
			} 
			next=next.nextSibling;
		} 
	}
	
	return null;
}
//获取指定标签名的元素子节点
dom.getChild=function(ele,tagName){
	var oChildNodes=ele.childNodes; 
	var arr=[];
	if(typeof tagName==="string"){ 
		for(var i=0;i<oChildNodes;i++){ 
			if(oChildNodes[i].nodeType===1&&oChildNodes[i].nodeName===tagName.toUpperCase()){ 
				arr.push(oChildNodes[i]);
			}
		}
	}else{ 
		for(var i=0;i<oChildNodes;i++){ 
			if(oChildNodes[i].nodeType===1){ 
				arr.push(oChildNodes[i]);
			}
		}

	}
	return arr;
}
//获取哥哥节点集合
dom.previousSiblings=function(ele){ 
	var arr=[];
	var pre=ele.previousSibling;
	while(pre){ 
		if(pre.nodeType===1){ 
			arr.unshift(pre)
		}
		pre=pre.previousSibling;
	}
	return arr;
}
//获取弟弟节点集合
dom.nextSiblings=function(ele){ 
	var arr=[];
	var next=ele.nextSibling;
	while(next){ 
		if(next.nodeType===1){ 
			arr.push(next)
		}
		next=next.nextSibling;
	}
	return arr;
}
//获取兄弟节点集合
dom.siblings=function(ele){ 
	return dom.previousSiblings(ele).concat(dom.nextSiblings(ele))
}
//通过className获取元素集合
dom.getElementsByClass=function(className,context){
	context=context||document;
	var allNodes=context.getElementsByTagName("*");
	var arr=[];
	var reg=new RegExp("(^| )"+className+"( |$)");
	for(var i=0;i<allNodes.length;i++){ 
		//alert(allNodes[i].className+" "+reg.test(allNodes[i].className));
		if(reg.test(allNodes[i].className)){ 

			arr.push(allNodes[i]);
		}else{ 
			continue;
		}
	}
	return arr;
}
//通过多重className进行筛选获取元素节点
dom.getElesByClass=function(strClass,context){
	context=context||document;
	if(context.getElementsByClassName){　
		return context.getElementsByClassName(str);
	}
	strClass=strClass.replace(/^ +| +$/g,""); //首尾去空
	var classArr=strClass.split(/ +/g);
	
	var allNodes=context.getElementsByTagName("*"),
		newArr=[];
	for(var i=0;i<classArr.length;i++){ 
		var reg=new RegExp("(^ +)"+classArr[i]+"( +$)");
		for(var j=0;j<allNodes.length;j++){ 
			if(reg.test(allNodes[j].className)){ 
				newArr.push(allNodes[j]);
			}
		}
		allNodes=newArr;
	}
	return newArr;
}
//添加className 如果存在不进行操作，如果没有则插入
dom.addClass=function(ele,className){ 
	var reg=new RegExp("(^| )"+className+"( |$)");
	if(!reg.test(ele.className)){
		 ele.className+=" "+className;
	}
}
//删除className如果存在删除，如果没有则不进行任何操作
dom.removeClass=function(ele,className){ 
	var reg=new RegExp("(^| )"+className+"( |$)","g");
	if(reg.test(ele.className)){ 
		var CName=ele.className.replace(reg," ");
		ele.className=CName;
	}
}
//字符串首尾去掉空格
dom.trim=function(str){
	if(typeof str==="string"){
		var reg=/^ +| +$/g;
		return str.replace(reg,"");
	}
}
/****************HTMLElement原型扩展******************
//扩展HTMLElemnet的原型方法，获取元素g的索引
HTMLElement.prototype.getIndex=function(){ 
	var index=0;
	var ele=this.previousSibling;
	while(ele){　
		if(ele.nodeType===1){ 
			index++;
		}
		ele=ele.previousSibling
	}
	return index;
}
//扩展HTMLElemnet的原型方法，获取元素距离顶部和左侧的距离
HTMLElement.prototype.getPos=function(){ 
	var pos={left:0,top:0};
	var that=this;
	do{ 
		pos.left+=that.offsetLeft;
		pos.top+=that.offsetTop;
		that=that.offsetParent;
	}while(that);
	return pos;
}
//获取哥哥节点集合
HTMLElement.prototype.previousSiblings=function(){ 
	var arr=[];
	var pre=this.previousSibling;
	while(pre){ 
		if(pre.nodeType===1){ 
			arr.unshift(pre)
		}
		pre=pre.previousSibling;
	}
	return arr;
}
//获取弟弟节点集合
HTMLElement.prototype.nextSiblings=function(){ 
	var arr=[];
	var next=this.nextSibling;
	while(next){ 
		if(next.nodeType===1){ 
			arr.push(next)
		}
		next=next.nextSibling;
	}
	return arr;
}
//获取兄弟节点
HTMLElement.prototype.siblings=function(){ 
	/*var a=[];
	var pre=this.previousSibling;
	while(pre){ 
		if(pre.nodeType===1){ 
			a.unshift(pre);
		}
		pre=pre.previousSibling;
	}
	var next=this.nextSibling;
	while(next){
		if(next.nodeType===1){
			a.push(next); 
		}
		next=next.nextSibling; 
	}
	return a;*
	return this.previousSiblings().concat(this.nextSiblings());

}
*/